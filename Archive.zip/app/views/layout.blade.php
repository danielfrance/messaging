<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Oh Hey</title>
	<link rel="stylesheet" href="packages/semantic/dist/semantic.min.css">
	<link rel="stylesheet" href="css/main.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
	<script src="packages/semantic/dist/semantic.min.js"></script>


</head>
<body>
	@yield('content')
</body>
</html>